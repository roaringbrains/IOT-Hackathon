﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.Net.Http;
using Nexus.Models;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Nexus.ViewModels;

namespace Nexus
{
	//[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ResultPageT : ContentPage
	{
        //private const string url = "http://35.227.109.154/iot/api/attendance";
        //private HttpClient _Client = new HttpClient();
        //private ObservableCollection<Student> _post;
        

        public ResultPageT ()
		{
            this.BackgroundColor = Color.FromHex("#E0F7FA");
            InitializeComponent();
            BindingContext = new StudentsViewModel();

        }

        void Handle_ItemTapped(object sender, ItemTappedEventArgs e)
       => ((ListView)sender).SelectedItem = null;

        void Handle_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var student = ((ListView)sender).SelectedItem as Attendance;
            if (student == null)
                return;


        }

        private bool isRowEven;

        private void Cell_OnAppearing(object sender, EventArgs e)
        {
            if (!this.isRowEven)
            {
                var viewCell = (ViewCell)sender;
                if (viewCell.View != null)
                {
                    viewCell.View.BackgroundColor = Color.Gray;
                }
            }

            this.isRowEven = !this.isRowEven;
        }

        //protected override async void OnAppearing()
        //{
        //    //string url1 = url + "?id=" + urlAddition;
        //    var content = await _Client.GetStringAsync(url);
        //    var post = JsonConvert.DeserializeObject<List<Student>>(content);
        //    _post = new ObservableCollection<Student>(post);
        //    Post_List.ItemsSource = _post;

        //    base.OnAppearing();
        //}
    }
}