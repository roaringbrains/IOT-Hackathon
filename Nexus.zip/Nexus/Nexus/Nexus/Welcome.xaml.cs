﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Nexus
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Welcome : ContentPage
	{
		public Welcome ()
		{
            Title = "NEXUS";
			InitializeComponent ();
            this.BackgroundColor = Color.FromHex("#E0F7FA");
        }

        //private async void Teacher(object sender, EventArgs e)
        //{
        //    await Navigation.PushAsync(new Teacher());
        //}
        private async void Teacher(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ResultPageT());
        }
        private async void ParentTransfer(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Parent());
        }
        private async void Admin(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Parent());
        }
    }
}