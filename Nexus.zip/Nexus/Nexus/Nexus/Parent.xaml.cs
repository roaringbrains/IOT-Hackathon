﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.Net.Http;
using Xamarin.Forms.Xaml;
using System.Net;

namespace Nexus
{

    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Parent : ContentPage
    {
        
        public Parent ()
		{
			InitializeComponent ();
            this.BackgroundColor = Color.FromHex("#E0F7FA");
            Entry txt_name = new Entry
            {
                WidthRequest = 250,
                HorizontalOptions = LayoutOptions.Start,
                Placeholder = "Enter Parent ID"
            };
            var txtlayout = new StackLayout
            {
                Padding = new Thickness(35, 20, 0, 0),
                Children ={
                    txt_name,
                },

            };
            txtlayout.WidthRequest = 10;
            Button btn_send = new Button
            {
                Text = "Send"
            };

            btn_send.Clicked += (sender, e) => {
                Navigation.PushAsync(new ResultPageP(txt_name.Text));
            };


            Content = new StackLayout
            {
                Children = {
                    txtlayout,btn_send
                }
            };
            Title = "Parent Login";
        }


        //private async void OnSubmit(object sender) => await Navigation.PushAsync(new ResultPage(parentId.Text));
        //Button btn_Submit = new Button
        //{
        //    Text = "Submit"
        //};

        //btn_Submit.Clicked += (sender, e) => {
        //        Navigation.PushAsync(new ResultPage(parent.Text));
        //    };




       
}
}