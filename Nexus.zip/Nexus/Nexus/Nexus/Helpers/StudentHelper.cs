﻿using Newtonsoft.Json;
using Nexus.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;

namespace Nexus.Helpers
{
    class StudentHelper
    {
        private static Random random;

        static HttpClient Client = new HttpClient();

        public static Attendance GetRandomStudent()
        {
            //var output = Newtonsoft.Json.JsonConvert.SerializeObject(Monkeys);
            return StudentsAttendance[random.Next(0, StudentsAttendance.Count)];
            // return Students[random.Next(0, Students.Where(a=>a.isPresent.CompareTo(true)))];
        }

        public static ObservableCollection<DisplayStudent> StudentsGrouped { get; set; }


        public static ObservableCollection<Attendance> StudentsAttendance { get; set; }
        public static ObservableCollection<Student> Students { get; set; }
        static StudentHelper()
        {

            IList<DisplayStudent> list = new List<DisplayStudent>();

            random = new Random();

            // Get Http Get Result
            const string url1 = "http://35.227.109.154/iot/api/student";
            var content1 = Client.GetStringAsync(url1).GetAwaiter().GetResult();
            var post1 = JsonConvert.DeserializeObject<List<Student>>(content1);

            Students = new ObservableCollection<Student>(post1);

            const string url = "http://35.227.109.154/iot/api/attendance";
            var content = Client.GetStringAsync(url).GetAwaiter().GetResult();
            var post = JsonConvert.DeserializeObject<List<Attendance>>(content);
            StudentsAttendance = new ObservableCollection<Attendance>(post);


            var presentees = (from s in Students
                              join a in StudentsAttendance on s.studentId equals a.studentId
                              where DateTime.Compare(a.attendanceDate.Date, DateTime.Today.Date) == 0
                              select new { StudentId = s.studentId }).ToList();
            var absentees = Students.Where(s => !presentees.Any(p2 => p2.StudentId == s.studentId)).ToList();

            // Get Http Get Result
            //const string url = "http://35.227.109.154/iot/api/attendance";
            //var content = Client.GetStringAsync(url).GetAwaiter().GetResult();
            //var post = JsonConvert.DeserializeObject<List<Attendance>>(content);

            //StudentsAttendance = new ObservableCollection<Attendance>(post);

   //         IList<DisplayStudent> StudentList = ((from p in StudentsAttendance
   //                            select new DisplayStudent { p.studentId, p.studentName, p.isPresent, p.attendanceDate.ToShortTimeString(), p.NameSort })
   //                            .Union(from a in absentees
   //                                   select ( a.studentId, a.name, false,  "", a.NameSort))).First();




   //var sorted = from student in StudentList
   //             orderby student.sname
   //                      select new Grouping<string, DisplayStudent>(studentGroup.Key, studentGroup);
   //         StudentsGrouped = new ObservableCollection<Grouping<string, Attendance>>(sorted);

            foreach(var p in StudentsAttendance)
            {
                list.Add(new DisplayStudent { sid = p.studentId, sname = p.studentName, present = p.isPresent, time = p.attendanceDate.ToShortTimeString(), namesort = p.NameSort });
            }


            foreach (var p in absentees)
            {
                list.Add(new DisplayStudent { sid = p.studentId, sname = p.name, present = false, time = "", namesort = p.NameSort });
            }


            StudentsGrouped = new ObservableCollection<DisplayStudent>(list);



        }


    }

    public class DisplayStudent
    {
        public long sid { get; set; }
        public string sname { get; set; }
        public bool present { get; set; }
        public string time { get; set; }
        public string namesort { get; set; }
        
    }
}

