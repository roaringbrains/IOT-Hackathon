﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nexus.Helpers
{
    public class UnderlineEffect 
    {
        //public const string EffectNamespace = "Example";

        //public UnderlineEffect() : base($"{EffectNamespace}.{nameof(UnderlineEffect)}")
        //{
        //}
    }
}
