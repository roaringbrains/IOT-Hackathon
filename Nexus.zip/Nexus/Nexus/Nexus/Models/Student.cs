﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nexus.Models
{
    class Student
    {
        public long studentId { get; set; }
        public string name { get; set; }
        public string parentName { get; set; }
        public string parentEmail { get; set; }
        public string parentPhone { get; set; }

        public string NameSort => name[0].ToString();
    }
}
