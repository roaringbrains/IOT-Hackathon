﻿using System;


namespace Nexus.Models
{
    public class Attendance
    {

        public int uniqueId { get; set; }
        public long schoolId { get; set; }
        public DateTime attendanceDate { get; set; }
        public long studentId { get; set; }
        public string studentName { get; set; }
        public long parentId { get; set; }
        public string parentName { get; set; }
        public long teacherId { get; set; }
        public string teacherName { get; set; }
        public string className { get; set; }
        public int termId { get; set; }
        public bool isPresent { get; set; }
        public bool isParentNotified { get; set; }

        public string NameSort => studentName[0].ToString();
    }

  
}

