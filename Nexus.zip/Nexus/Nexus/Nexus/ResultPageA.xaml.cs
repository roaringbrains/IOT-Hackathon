﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.Net.Http;
using Nexus.Models;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Nexus
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ResultPageA : ContentPage
	{

        private const string url = "http://jsonplaceholder.typicode.com/todos";
        private HttpClient _Client = new HttpClient();
        private ObservableCollection<PostCard> _post;
        private string urlAddition;
        public ResultPageA (string data)
		{
            Title = "Result Page";
            this.BackgroundColor = Color.FromHex("#E0F7FA");
            InitializeComponent ();
            urlAddition = data;

        }

        protected override async void OnAppearing()
        {
            string url1 = url + "?id=" + urlAddition;
            var content = await _Client.GetStringAsync(url1);
            var post = JsonConvert.DeserializeObject<List<PostCard>>(content);
            _post = new ObservableCollection<PostCard>(post);
            Post_List.ItemsSource = _post;

            base.OnAppearing();
        }
    }
}