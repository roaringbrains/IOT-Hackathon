﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nexus.ViewModels;
using Nexus.Models;
using Nexus.Helpers;
using Xamarin.Forms;

namespace Nexus
{
    public static class ViewModelLocator
    {
        static StudentsViewModel studentsVM;
        public static StudentsViewModel StudentsViewModel
        => studentsVM ?? (studentsVM = new StudentsViewModel());

        //static DetailsViewModel detailsVM;
        //public static DetailsViewModel DetailsViewModel
        //=> detailsVM ?? (detailsVM = new DetailsViewModel(MonkeyHelper.Monkeys[0]));
    }
    public partial class App : Application
	{
		public App ()
		{
			InitializeComponent();

            //MainPage = new Nexus.MainPage();
            MainPage = new NavigationPage(new Nexus.SplashPage());
        }

		protected override void OnStart ()
		{
			// Handle when your app starts
		}

		protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}
	}
}
