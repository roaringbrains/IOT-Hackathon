﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using Nexus.Models;
using Nexus.Helpers;


namespace Nexus.ViewModels
{
    public class StudentsViewModel
    {

        public ObservableCollection<Attendance> Students { get; set; }
        public ObservableCollection<DisplayStudent> StudentsGrouped { get; set; }

        public StudentsViewModel()
        {

            Students = StudentHelper.StudentsAttendance;
            StudentsGrouped = StudentHelper.StudentsGrouped;
        }

        public int StudentCount => Students.Count;

    }
}
