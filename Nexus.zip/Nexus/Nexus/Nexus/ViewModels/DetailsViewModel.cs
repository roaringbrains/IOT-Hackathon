﻿using System;
using System.Collections.Generic;
using System.Text;
using Nexus.Models;

namespace Nexus.ViewModels
{
    class DetailsViewModel
    {
        public Attendance Student { get; set; }
        public DetailsViewModel(Attendance student)
        {
            Student = student;
        }
    }
}
