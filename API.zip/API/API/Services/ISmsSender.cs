﻿using System.Threading.Tasks;

namespace API.Services
{
    internal interface ISmsSender
    {
        Task SendSmsAsync(string number, string message);
    }
}