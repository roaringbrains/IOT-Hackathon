﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Models;
using API.Models.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace API.Controllers
{
    [Route("api/[controller]")]
    public class StudentController : Controller
    {
        //private IDataRepository<Student, long> _iRepo;
        //public StudentController(IDataRepository<Student, long> repo)
        //{
        //    _iRepo = repo;
        //}

        // GET: api/values  
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            //return _iRepo.GetAll();
            using (ApplicationContext db = new
            ApplicationContext())
            {
                return db.Students.ToList();
            }
        }

        // GET api/values/5  
        [HttpGet("{id}")]
        public Student Get(int id)
        {
            //return _iRepo.Get(id);
            using (ApplicationContext db = new
            ApplicationContext())
            {
                return db.Students.Find(id);
            }
        }

        // POST api/values  
        [HttpPost]
        public IActionResult Post([FromBody]Student student)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Students.Add(student);
                db.SaveChanges();
                return new ObjectResult("Student added successfully!");
            }
        }

        // POST api/values  
        [HttpPut]
        public IActionResult Put([FromBody]Student student)
        {
            //_iRepo.Update(student.StudentId, student);
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Entry<Student>(student).State = EntityState.Modified;
                db.SaveChanges();
                return new ObjectResult("Employee modified successfully!");
            }
        }

        // DELETE api/values/5  
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            //return _iRepo.Delete(id);
            using (ApplicationContext db = new ApplicationContext())
            {

                db.Students.Remove(db.Students.Find(id));
                db.SaveChanges();
                return new ObjectResult("Employee deleted successfully!");
            }
        }
    }
}
