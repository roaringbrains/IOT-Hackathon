﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using API.Models;
using API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace API.Controllers
{
    [Route("api/[controller]")]
    public class AttendanceController : Controller
    {
        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<Attendance> Get()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                //AuthMessageSender sender = new AuthMessageSender();
                //sender.SendEmailAsync("nexus.hackathon@gmail.com", "Powerschool Hack Email Test", "API says Hi!");
                return db.AttendanceReg.GroupBy(a => a.StudentId).Select(x => x.First()).ToList();

            }
        }

        [HttpGet("{id}")]
        public Attendance Get(int id)
        {
            using (ApplicationContext db = new
            ApplicationContext())
            {
                return db.AttendanceReg.Find(id);
            }
        }

        // POST api/<controller>
        //[HttpPost]
        //public IActionResult Post([FromBody]Attendance attendance)
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        db.AttendanceReg.Add(attendance);
        //        db.SaveChanges();
        //        return new ObjectResult("Attendance added successfully!");
        //    }
        //}

        [HttpPost]
        public IActionResult Post([FromBody]string value)
        {
            long studentId = 0;
            long.TryParse(value, out studentId);
            ApplicationContext db = new ApplicationContext();
            var attendance = new Attendance();
            var student = db.Students.Where(s => s.StudentId == studentId).FirstOrDefault();
            attendance.StudentId = studentId;
            attendance.SchoolId = 12345;
            attendance.StudentName = student.Name;
            attendance.ParentId = 123456;
            attendance.ParentName = student.ParentName;
            attendance.TeacherId = 1234567;
            attendance.TeacherName = "John Adams";
            attendance.TermId = 123;
            attendance.IsPresent = true;
            attendance.IsParentNotified = false;
            attendance.ClassName = "Science";
            attendance.AttendanceDate = DateTime.Now;

            {
                db.AttendanceReg.Add(attendance);
                db.SaveChanges();
                Thread.Sleep(30000);
                SendEmail();
                return new ObjectResult("Attendance added successfully!");
            }           
        }

        private void SendEmail()
        {
            ApplicationContext db = new ApplicationContext();
            var presentees = (from s in db.Students
                                         join a in db.AttendanceReg on s.StudentId equals a.StudentId
                                         where DateTime.Compare(a.AttendanceDate.Value.Date, DateTime.Today.Date) == 0
                             select new { StudentId = s.StudentId}).ToList();
            var absentees = db.Students.Where(s => !presentees.Any(p2 => p2.StudentId == s.StudentId)).ToList();

            foreach(var a in absentees)
            {
                AuthMessageSender sender = new AuthMessageSender();
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Dear {0}, {1} Your child {2} didn't attend the school on {3}. {4}Regards,{5}School Admin", a.ParentName, Environment.NewLine, a.Name, DateTime.Today.ToShortDateString(), Environment.NewLine, Environment.NewLine);
                sender.SendEmailAsync(a.ParentEmail, "Absence Notice!!", sb.ToString());
            }
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]Attendance attendance)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Entry<Attendance>(attendance).State = EntityState.Modified;
                db.SaveChanges();
                return new ObjectResult("Attendance modified successfully!");
            }
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                db.AttendanceReg.Remove(db.AttendanceReg.Find(id));
                db.SaveChanges();
                return new ObjectResult("Attendance deleted successfully!");
            }
        }
    }
}
