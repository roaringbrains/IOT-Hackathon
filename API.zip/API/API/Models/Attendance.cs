﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models
{
    [Table("Attendance")]
    public class Attendance
    {
        [DatabaseGenerated(DatabaseGeneratedOption
         .Identity)]
        [Key]
        public int UniqueId { get; set; }
        public int SchoolId { get; set; }
        public DateTime? AttendanceDate { get; set; }
        public long StudentId { get; set; }
        public string StudentName { get; set; }
        public long ParentId { get; set; }
        public string ParentName { get; set; }
        public long TeacherId { get; set; }
        public string TeacherName { get; set; }
        public string ClassName { get; set; }
        public int TermId { get; set; }
        public bool IsPresent { get; set; }
        public bool IsParentNotified { get; set; }

    }
}
