﻿using API.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models.DataManager
{
    public class StudentManager : IDataRepository<Student, long>
    {
        ApplicationContext ctx;
        public StudentManager(ApplicationContext c)
        {
            ctx = c;
        }

        public Student Get(long id)
        {
            var student = ctx.Students.FirstOrDefault(b => b.StudentId == id);
            return student;
        }

        public IEnumerable<Student> GetAll()
        {
            var students = ctx.Students.ToList();
            return students;
        }

        public long Add(Student stundent)
        {
            ctx.Students.Add(stundent);
            long studentID = ctx.SaveChanges();
            return studentID;
        }

        public long Delete(long id)
        {
            int studentID = 0;
            var student = ctx.Students.FirstOrDefault(b => b.StudentId == id);
            if (student != null)
            {
                ctx.Students.Remove(student);
                studentID = ctx.SaveChanges();
            }
            return studentID;
        }

        public long Update(long id, Student item)
        {
            long studentID = 0;
            var student = ctx.Students.Find(id);
            if (student != null)
            {
                student.Name = item.Name;
                student.ParentName = item.ParentName;
                student.ParentEmail = item.ParentEmail;
                student.ParentPhone = item.ParentPhone;
                
                studentID = ctx.SaveChanges();
            }
            return studentID;
        }
    }
}
