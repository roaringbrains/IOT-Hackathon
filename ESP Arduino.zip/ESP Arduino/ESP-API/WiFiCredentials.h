//Insert your WiFi credentials here
static const char* WiFiSSID = "Kishore";
static const char* WiFiPassword = "berry123";